import { ensureSchema } from "@/db/ensure";
import { db } from "@/db";
import { scores } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSchema();
  const rows = await db.select().from(scores).orderBy(desc(scores.score)).limit(20);
  return Response.json(rows);
}

export async function POST(req: Request) {
  await ensureSchema();
  const b = await req.json();
  const name = String(b.name || "Pilot").slice(0, 16);
  const score = Math.max(0, Math.min(1e7, Number(b.score) | 0));
  await db.insert(scores).values({ name, score, mode: String(b.mode || "").slice(0, 20), map: String(b.map || "").slice(0, 30) });
  return Response.json({ ok: true });
}
